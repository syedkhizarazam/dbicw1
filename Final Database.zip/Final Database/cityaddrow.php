<?php

include('conn.php');
include 'mystyle.css';
if($conn -> connect_error){
	die("Connection failed" . mysqli_connect_error());
}

$id=$_GET["id"];
$name=$_GET["name"];
$countrycode=$_GET["countrycode"];
$district=$_GET["district"];
$population=$_GET["population"];


$query = "INSERT INTO city (ID, Name, CountryCode, District, Population) 
		  VALUES ('$id', '$name', '$countrycode', '$district', '$population')";

if(mysqli_query($conn, $query)){
	echo "<h1>Success</h1>";
	echo "<br>";
	echo "<a href='http://localhost/city.php' class='back'>Back</a>";
}
else {
	echo "Error. Problem could have been caused by non-existant CountryCode." .mysqli_error($conn);
		echo "<a href='http://localhost/city.php' class='back'>Back</a>";
}

mysqli_close($conn);

?>
<html>
<head>
<link rel="stylesheet" href="mystyle.css">
<meta name="viewport" content="width=device-width,initial-scale=1">
</head>
</html>