<?php
	include('conn.php');
	?>

<html>
<head>
	<link rel="stylesheet" href="mystyle.css">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	</head>

	<form action="cityaddrow.php" method="get">
		ID &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<br><input type="number" name="id" required><br><br>
		Name
		<br><input type="text" name="name"><br><br>
		CountryCode
		<br><input type="text" name="countrycode";><br><br>
		District
		<br><input type="text" name="district" required;><br><br>
		Population
		<br><input type="number" name="population";><br><br>
		<br><input type="submit" class="back">
	</form>

</html>