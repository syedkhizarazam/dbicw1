<?php

include('conn.php');
include 'mystyle.css';
if($conn -> connect_error){
	die("Connection failed" . mysqli_connect_error());
}

$countrycode=$_GET["countrycode"];
$countryname=$_GET["countryname"];
$continent=$_GET["continent"];
$region=$_GET["region"];
$surfacearea=$_GET["surfacearea"];
$independanceyear=$_GET["independanceyear"];
$population=$_GET["population"];
$lifeexpectancy=$_GET["lifeexpectancy"];
$gnp=$_GET["gnp"];
$oldgnp=$_GET["oldgnp"];
$localname=$_GET["localname"];
$governmentform=$_GET["governmentform"];
$headofstate=$_GET["headofstate"];
$capital=$_GET["capital"];
$isocode=$_GET["isocode"];

$query = "INSERT INTO country (CountryCode, Name, Continent, Region, SurfaceArea, 
								IndependanceYear, Population, LifeExpectancy,
								GNP, GNP_Old, LocalName, GovernmentForm,
								HeadOfState, Capital, ISO_Code)
		  VALUES ('$countrycode', '$countryname', '$continent', '$region', '$surfacearea',
				  '$independanceyear', '$population', '$lifeexpectancy', '$gnp', '$oldgnp',
				  '$localname', '$governmentform', '$headofstate', '$capital', '$isocode')";

if(mysqli_query($conn, $query)){
	echo "Success";
	echo "<a href='http://localhost/country.php' class='back'>Back</a>";
}
else {
	echo "Error" .mysqli_error($conn);
	echo "<a href='http://localhost/country.php' class='back'>Back</a>";
}

mysqli_close($conn);

?>

<html>
<head>
<link rel="stylesheet" href="mystyle.css">
</head>
</html>