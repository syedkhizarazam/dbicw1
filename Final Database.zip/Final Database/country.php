<?php
	session_start();
	include('conn.php');
	?>

<!doctype html>
<html>
<head> 
	<title>Country</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="mystyle.css">
</head>

<body>
	<h1>Database & Interface</h1>
	<h2>Country</h2>
	
	<p><a href="home.html" class="back">Back to Homepage </a></p>
	
<?php
include 'mystyle.css';
mysqli_set_charset($conn,"utf8");

$sql = "SELECT * FROM country";
$sqldata = mysqli_query($conn, $sql) or die ('Error');
mysqli_query($conn,"set character_set_results='utf8'"); 

$link_address1 = 'countryaddrowinput.php';
echo "<a href=".$link_address1." class='back'>Add</a>";

echo "<table>";
echo "<table border='1'><tr>";
echo "<tr><th>CountryCode</th><th>Name</th><th>Continent</th>
	  <th>Region</th><th>SurfaceArea</th><th>IndependanceYear</th>
	  <th>Population</th><th>LifeExpectancy</th><th>GNP</th><th>Old GNP</th>
	  <th>Local Name</th><th>Government Form</th><th>Head of State</th><th>Capital</th>
	  <th>ISO_Code</th></tr>";

while($row = mysqli_fetch_array($sqldata, MYSQLI_ASSOC)){
	echo "<tr>";
	echo "<td>";
	echo $row['CountryCode'];
	echo "</td>";
	echo "<td>";
	echo $row['Name'];
	echo "</td>";
	echo "<td>";
	echo $row['Continent'];
	echo "</td>";
	echo "<td>";
	echo $row['Region'];
	echo "</td>";
	echo "<td>";
	echo $row['SurfaceArea'];
	echo "</td>";
	echo "<td>";
	echo $row['IndependanceYear'];
	echo "</td>";
	echo "<td>";
	echo $row['Population'];
	echo "</td>";
	echo "<td>";
	echo $row['LifeExpectancy'];
	echo "</td>";
	echo "<td>";
	echo $row['GNP'];
	echo "</td>";
	echo "<td>";
	echo $row['GNP_Old'];
	echo "</td>";
	echo "<td>";
	echo $row['LocalName'];
	echo "</td>";
	echo "<td>";
	echo $row['GovernmentForm'];
	echo "</td>";
	echo "<td>";
	echo $row['HeadOfState'];
	echo "</td>";
	echo "<td>";
	echo $row['Capital'];
	echo "</td>";
	echo "<td>";
	echo $row['ISO_Code'];
	echo "</td>";
	echo "<td>";
	echo "<a href='countryeditinput.php?rowid=".$row['CountryCode']."'>Edit</a>";
	echo "</td>";
	echo "<td>";
	echo "<a href='countrydelete.php?rowid=".$row['CountryCode']."'>Delete</a>";
	echo "</td>";
}
echo "</table>";

?>
</body>

</html>