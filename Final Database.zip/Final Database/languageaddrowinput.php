<?php
	include('conn.php');
	?>

<html>
	<head>
	<link rel="stylesheet" href="mystyle.css">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	</head>
	<form action="languageaddrow.php" method="get">
		CountryCode &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<br><input type="text" name="countrycode"><br><br>
		Language
		<br><input type="text" name="language"><br><br>
		IsOfficial(T/F)
		<br><input type="text" name="isofficial" required pattern="[T-TF-F]{1}";><br><br>
		Percentage(Inputs larger than 100 will be set to 100)
		<br><input type="number" step="any" name="percentage" min="0" max="100" required pattern="[0-9]*{3}"><br>
		<br><input type="submit" class="back">
	</form>

</html>