<?php
	
	session_start();
	
	include('conn.php');

$countrycode=$_SESSION["rowid"];
$countryname=$_GET["countryname"];
$continent=$_GET["continent"];
$region=$_GET["region"];
$surfacearea=$_GET["surfacearea"];
$independanceyear=$_GET["independanceyear"];
$population=$_GET["population"];
$lifeexpectancy=$_GET["lifeexpectancy"];
$gnp=$_GET["gnp"];
$oldgnp=$_GET["oldgnp"];
$localname=$_GET["localname"];
$governmentform=$_GET["governmentform"];
$headofstate=$_GET["headofstate"];
$capital=$_GET["capital"];
$isocode=$_GET["isocode"];
	
	$sql = "UPDATE country SET Name='$countryname', Continent='$continent', Region='$region',
								SurfaceArea='$surfacearea', IndependanceYear='$independanceyear',
								Population='$population', LifeExpectancy='$lifeexpectancy',
								GNP='$gnp', GNP_Old='$oldgnp', LocalName='$localname',
								GovernmentForm='$governmentform', HeadOfState='$headofstate',
								Capital='$capital', ISO_Code='$isocode' WHERE CountryCode='$countrycode'";
	
	if(mysqli_query($conn, $sql)){
	echo "Success";
	echo "<a href='http://localhost/country.php' class='back'>Back</a>";
}
else {
	echo "Error" .mysqli_error($conn);
	echo "<a href='http://localhost/country.php' class='back'>Back</a>";
}

mysqli_close($conn);
	
?>
<html>
<head>
<link rel="stylesheet" href="mystyle.css">
</head>
<body>
</body>
</html>