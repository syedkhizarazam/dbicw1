<?php

	session_start();
	include('conn.php');
	$_SESSION["rowid"]=$_GET["rowid"];
	$_SESSION["rowid2"]=$_GET["rowid2"];
	?>

<html>
	<head>
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="stylesheet" href="mystyle.css">
	</head>

	<form action="languageedit.php", method="get">
		Language &nbsp;&nbsp;
		<br><input type="text" name="language"><br><br>
		IsOfficial &nbsp;&nbsp;
		<br><input type="text" name="isofficial"><br><br>
		PercentageSpoken &nbsp;&nbsp;
		<br><input type="text" name="percentagespoken"><br><br>
		<br><input type="submit" class="back">
	</form>

</html>

