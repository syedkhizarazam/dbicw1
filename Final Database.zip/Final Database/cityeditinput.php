<?php
	include 'mystyle.css';
	session_start();
	include('conn.php');
	$_SESSION["rowid"]=$_GET["rowid"];
	?>

<html>
<head>
	<link rel="stylesheet" href="mystyle.css">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	</head>

	<form action="cityedit.php" method="get">
		Name
		<br><input type="text" name="name"><br><br>
		CountryCode
		<br><input type="text" name="countrycode" required;><br><br>
		District
		<br><input type="text" name="district" ;><br><br>
		Population
		<br><input type="number" name="population";><br><br>
		<br><input type="submit" class="back">
	</form>

</html>