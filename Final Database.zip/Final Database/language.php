<?php
	session_start();
	include('conn.php');
	?>

<!doctype html>
<html>
<head> 
	<title>Lang</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="mystyle.css">
	<meta name="viewport" content="width=device-width,initial-scale=1">
</head>

<body>
	
	<h1>Database & Interface</h1>
	<h2>LANGUAGE</h2>
		
	<p><a href="home.html" class="back">Back to Homepage </a></p>
	
<?php
include 'mystyle.css';
$sql = "SELECT * FROM language";
$sqldata = mysqli_query($conn, $sql) or die ('Error');
mysqli_query($conn,"set character_set_results='utf8'"); 

$link_address1 = 'languageaddrowinput.php';
echo "<a href=".$link_address1." class='back'>Add</a>";

echo "<table>";
echo "<table border='1'><tr>";
echo "<tr><th>CountryCode</th><th>Language</th><th>IsOfficial</th><th>PercentageSpoken</th></tr>";

while($row = mysqli_fetch_array($sqldata, MYSQLI_ASSOC)){
	echo "<tr>";
	echo "<td>";
	echo $row['CountryCode'];
	echo "</td>";
	echo "<td>";
	echo $row['Language'];
	echo "</td>";
	echo "<td>";
	echo $row['IsOfficial'];
	echo "</td>";
	echo "<td>";
	echo $row['Percentage'];
	echo "</td>";
	echo "<td>";
	echo "<a href='languageeditinput.php?rowid=".$row['CountryCode']."&rowid2=".$row['Language']."'>Edit</a>";
	echo "</td>";
	echo "<td>";
	echo "<a href='languagedelete.php?rowid=".$row['CountryCode']."&rowid2=".$row['Language']."'>Delete</a>";
	echo "</td>";
}
echo "</table>";

?>
</body>

</html>