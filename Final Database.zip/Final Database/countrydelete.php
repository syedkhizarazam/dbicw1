<?php

	include('conn.php');

$rowid=$_GET["rowid"];
$query="DELETE from country WHERE CountryCode='$rowid'";
if(mysqli_query($conn, $query)){
	echo "Success";
	echo "<a href='http://localhost/country.php' class='back'>Back</a>";
}
else {
	echo "Error" .mysqli_error($conn);
	echo "<a href='http://localhost/country.php' class='back'>Back</a>";
}
?>
<html>
<head>
<link rel="stylesheet" href="mystyle.css">
</head>
<body>
</body>
</html>
