<?php
	session_start();
	include('conn.php');
	?>

<!doctype html>
<html>
<head> 
	<title>Lang</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="style.css">
	<meta name="viewport" content="width=device-width,initial-scale=1">
</head>

<body>
	<h2>LANGUAGE</h2>
	
	<div class="search-box">
		<input class="search-txt" type="text" name="" placeholder="Type to search" >
		<a class="search-btn" href="#"></a>
	</div>
	
	<p><a href="home.html">BACK TO HOMEPAGE</a></p>
	
<?php
include 'mystyle.css';
$sql = "SELECT * FROM language";
$sqldata = mysqli_query($conn, $sql) or die ('Error');
mysqli_query($conn,"set character_set_results='utf8'"); 

$link_address1 = 'languageaddrowinput.php';
echo "<a href=".$link_address1.">Add</a>";

echo "<table>";
echo "<table border='1'><tr>";
echo "<tr><th>CountryCode</th><th>Language</th><th>IsOfficial</th><th>PercentageSpoken</th></tr>";

while($row = mysqli_fetch_array($sqldata, MYSQLI_ASSOC)){
	?>
	<tr>
	<td>	
	<?php echo $row['CountryCode']; ?>
	</td>
	<td>
	<?php echo $row['Language']; ?>
	</td>
	<td>
	<?php echo $row['IsOfficial']; ?>
	</td>
	<td>
	<?php echo $row['Percentage']; ?>
	</td>
	<td>
	<?php echo "<a href='languageeditinput.php?rowid=".$row['CountryCode']."&rowid2=".$row['Language']."'>Edit</a>"; ?>
	</td>
	<td>
	<?php echo "<a href='languagedelete.php?rowid=".$row['CountryCode']."&rowid2=".$row['Language']."'>Delete</a>"; ?>
	</td>
	<?php
}
?>
<?php
echo "</table>";
?>

</body>

</html>