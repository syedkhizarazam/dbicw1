<?php

include('conn.php');
include 'mystyle.css';
if($conn -> connect_error){
	die("Connection failed" . mysqli_connect_error());
}

$countrycode=$_GET["countrycode"];
$language=$_GET["language"];
$isofficial=$_GET["isofficial"];
$percentage=$_GET["percentage"];

$query = "INSERT INTO language (CountryCode, Language, IsOfficial, Percentage) VALUES ('$countrycode', '$language', '$isofficial', '$percentage')";

if(mysqli_query($conn, $query)){
	echo "<h1>Success</h1>";
	echo "<br>";
	echo "<a href='http://localhost/language.php' class='back'>Back</a>";
}
else {
	echo "Error. Problem could have been caused by non-existant CountryCode." .mysqli_error($conn);
	echo "<a href='http://localhost/language.php' class='back'>Back</a>";
}

mysqli_close($conn);



?>

<html>
<head>
<link rel="stylesheet" href="mystyle.css">
<meta name="viewport" content="width=device-width,initial-scale=1">
</head>
</html>