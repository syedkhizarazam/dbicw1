<?php
	
	session_start();
	
	include('conn.php');
	
	$language=$_GET["language"];
	$isofficial=$_GET["isofficial"];
	$percentagespoken=$_GET["percentagespoken"];
	$rowid=$_SESSION["rowid"];
	$rowid2=$_SESSION["rowid2"];
	
	$sql = "UPDATE language SET Language='$language', IsOfficial='$isofficial', Percentage='$percentagespoken' WHERE CountryCode='$rowid' AND Language='$rowid2'";
	if(mysqli_query($conn, $sql)){
	echo "<h1>Success</h1>";
	echo "<a href='http://localhost/language.php' class='back'>Back</a>";
}
else {
	echo "Error" .mysqli_error($conn);
	echo "<a href='http://localhost/language.php' class='back'>Back</a>";
}

mysqli_close($conn);
	
?>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="mystyle.css">
</head>
<body>
</body>
</html>