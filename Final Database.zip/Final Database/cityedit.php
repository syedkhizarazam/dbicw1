<?php
	include 'mystyle.css';
	session_start();
	
	include('conn.php');

$rowid=$_SESSION["rowid"];
$name=$_GET["name"];
$countrycode=$_GET["countrycode"];
$district=$_GET["district"];
$population=$_GET["population"];
	
	$sql = "UPDATE city SET Name='$name', CountryCode='$countrycode', District='$district',
							Population='$population' WHERE ID='$rowid'";
	
	if(mysqli_query($conn, $sql)){
	echo "<h1>Success</h1>";
	echo "<a href='http://localhost/city.php' class='back'>Back</a>";
}
else {
	echo "Error" .mysqli_error($conn);
	echo "<a href='http://localhost/city.php' class='back'>Back</a>";
}

mysqli_close($conn);
	
?>
<html>
<head>
<link rel="stylesheet" href="mystyle.css">
<meta name="viewport" content="width=device-width,initial-scale=1">
</head>
<body>
</body>
</html>