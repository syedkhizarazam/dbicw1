<?php
	session_start();
	include('conn.php');
	?>

<!doctype html>
<html>
<head> 
	<title>City</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="mystyle.css">
	<meta name="viewport" content="width=device-width,initial-scale=1">
</head>

<body>
	<h1>Database & Interface</h1>
	<h2>City</h2>
	
	<p><a href="home.html" class="back">Back to Homepage </a></p>
	
<?php
include 'mystyle.css';
mysqli_set_charset($conn,"utf8");

$sql = "SELECT * FROM city";
$sqldata = mysqli_query($conn, $sql) or die ('Error');
mysqli_query($conn,"set character_set_results='utf8'"); 

$link_address1 = 'cityaddrowinput.php';
echo "<a href=".$link_address1." class='back'>Add</a>";

echo "<table>";
echo "<table border='1'><tr>";
echo "<tr><th>ID</th><th>Name</th><th>CountryCode</th><th>District</th><th>Population</th></tr>";

while($row = mysqli_fetch_array($sqldata, MYSQLI_ASSOC)){
	echo "<tr>";
	echo "<td>";
	echo $row['ID'];
	echo "</td>";
	echo "<td>";
	echo $row['Name'];
	echo "</td>";
	echo "<td>";
	echo $row['CountryCode'];
	echo "</td>";
	echo "<td>";
	echo $row['District'];
	echo "</td>";
	echo "<td>";
	echo $row['Population'];
	echo "</td>";
	echo "<td>";
	echo "<a href='cityeditinput.php?rowid=".$row['ID']."'>Edit</a>";
	echo "</td>";
	echo "<td>";
	echo "<a href='citydelete.php?rowid=".$row['ID']."'>Delete</a>";
	echo "</td>";
}
echo "</table>";

?>
</body>

</html>