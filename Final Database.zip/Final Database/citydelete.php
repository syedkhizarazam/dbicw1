<?php

	include('conn.php');

$rowid=$_GET["rowid"];
$query="DELETE from city WHERE ID='$rowid'";
if(mysqli_query($conn, $query)){
	echo "<h1>Success</h1>";
	echo "<a href='http://localhost/city.php' class='back'>Back</a>";
}
else {
	echo "Error" .mysqli_error($conn);
	echo "<a href='http://localhost/city.php' class='back'>Back</a>";
}
?>
<html>
<head>
<link rel="stylesheet" href="mystyle.css">
<meta name="viewport" content="width=device-width,initial-scale=1">
</head>
<body>
</body>
</html>
