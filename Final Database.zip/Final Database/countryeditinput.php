<?php

	session_start();
	include('conn.php');
	$_SESSION["rowid"]=$_GET["rowid"];
	?>

<html>
<head>
	<link rel="stylesheet" href="mystyle.css">
	</head>

	<form action="countryedit.php" method="get">
		Country Name
		<br><input type="text" name="countryname"><br><br>
		Continent
		<br><input type="text" name="continent";><br><br>
		Region
		<br><input type="text" name="region"><br><br>
		Surface Area
		<br><input type="text" name="surfacearea"><br><br>
		Independance Year
		<br><input type="text" name="independanceyear"><br><br>
		Population
		<br><input type="text" name="population"><br><br>
		Life Expectancy
		<br><input type="text" name="lifeexpectancy"><br><br>
		GNP
		<br><input type="number" name="gnp"><br><br>
		Old GNP
		<br><input type="text" name="oldgnp"><br><br>
		Local Name
		<br><input type="text" name="localname"><br><br>
		Government Form
		<br><input type="text" name="governmentform"><br><br>
		Head of State
		<br><input type="text" name="headofstate"><br><br>
		Capital Code (From City table)
		<br><input type="text" name="capital" pattern="[0-9]*" ><br><br>
		ISO Code
		<br><input type="text" name="isocode"><br><br>
		<br><input type="submit" class="back">
	</form>

</html>

