<?php

	include('conn.php');

$rowid=$_GET["rowid"];
$rowid2=$_GET["rowid2"];
$query="DELETE from language WHERE CountryCode='$rowid' AND Language='$rowid2'";
if(mysqli_query($conn, $query)){
	echo "<h1>Success</h1>";
	echo "<a href='http://localhost/language.php' class='back'>Back</a>";
}
else {
	echo "Error";
	echo "<a href='http://localhost/language.php' class='back'>Back</a>";
}
?>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="mystyle.css">
</head>
<body>
</body>
</html>